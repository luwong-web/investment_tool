"""LLM 打分。有 DEEPSEEK_API_KEY 走 DeepSeek,否则关键词 mock 兜底。"""
import json
import logging
import re
from typing import Optional

from openai import OpenAI

from config import (
    DEEPSEEK_API_KEY,
    DEEPSEEK_BASE_URL,
    DEEPSEEK_MODEL,
    USE_MOCK_LLM,
)

log = logging.getLogger("scorer")

_SYSTEM_PROMPT = """你是金融投研分析师,判断每条新闻对 A 股/港股/美股市场的短期股价影响。
评级三档:
- 高:可能引发指数级或板块级明显波动。如央行货币政策转向、重大地缘冲突、超预期通胀数据、行业级监管政策、龙头公司黑天鹅。
- 中:公司层面或细分行业级别的实质影响。如个股业绩爆雷/超预期、行业订单变化、次要政策调整。
- 低:一般动态、市场评论、无明确交易信号。

对每条新闻,输出严格 JSON 数组,格式:
[{"id":"<原样返回>","impact":"高|中|低","reason":"20字内一句话解释","sectors":["涉及板块1","板块2"]}]

只输出 JSON 数组,不要任何解释文字。sectors 数组最多 3 项,可为空。"""

_MOCK_HIGH = ["降息", "加息", "美联储", "央行", "地缘", "战争", "制裁", "关税",
              "监管", "熔断", "暴跌", "破产", "退市", "重大", "黑天鹅", "冲突"]
_MOCK_MED = ["业绩", "回购", "增持", "减持", "收购", "并购", "订单", "签约",
             "涨停", "跌停", "预警", "重组", "IPO", "上市", "分红"]


def _build_client() -> Optional[OpenAI]:
    if USE_MOCK_LLM:
        return None
    return OpenAI(api_key=DEEPSEEK_API_KEY, base_url=DEEPSEEK_BASE_URL)


_client = _build_client()


def _mock_score(items: list[dict]) -> list[dict]:
    out = []
    for it in items:
        t = it["title"]
        if any(k in t for k in _MOCK_HIGH):
            impact, reason = "高", "关键词命中:宏观/政策级事件"
        elif any(k in t for k in _MOCK_MED):
            impact, reason = "中", "关键词命中:公司/行业级动态"
        else:
            impact, reason = "低", "一般市场动态"
        out.append({
            "id": it["id"],
            "impact": impact,
            "reason": reason,
            "sectors": [],
        })
    return out


def _parse_llm_json(raw: str) -> list[dict]:
    m = re.search(r"\[.*\]", raw, re.S)
    if not m:
        raise ValueError("no JSON array")
    return json.loads(m.group(0))


def score_batch(items: list[dict]) -> list[dict]:
    if not items:
        return []

    if _client is None:
        return _mock_score(items)

    user_payload = json.dumps(
        [{"id": it["id"], "title": it["title"], "source": it.get("source", "")} for it in items],
        ensure_ascii=False,
    )

    try:
        resp = _client.chat.completions.create(
            model=DEEPSEEK_MODEL,
            messages=[
                {"role": "system", "content": _SYSTEM_PROMPT},
                {"role": "user", "content": f"新闻列表:\n{user_payload}"},
            ],
            temperature=0.2,
            timeout=30,
        )
        raw = resp.choices[0].message.content or ""
        parsed = _parse_llm_json(raw)
    except Exception as e:
        log.warning("deepseek call failed: %s — falling back to mock", e)
        return _mock_score(items)

    by_id = {p.get("id"): p for p in parsed if isinstance(p, dict)}
    out = []
    for it in items:
        p = by_id.get(it["id"])
        if not p or p.get("impact") not in ("高", "中", "低"):
            out.append({"id": it["id"], "impact": "低", "reason": "打分格式异常", "sectors": []})
        else:
            out.append({
                "id": it["id"],
                "impact": p["impact"],
                "reason": (p.get("reason") or "")[:60],
                "sectors": [s for s in (p.get("sectors") or []) if isinstance(s, str)][:3],
            })
    return out
