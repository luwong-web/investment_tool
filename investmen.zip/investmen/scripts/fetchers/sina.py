import hashlib
import json
import logging
import re

import httpx

from config import HTTP_HEADERS, SINA_URL

log = logging.getLogger("fetcher.sina")


async def fetch() -> list[dict]:
    async with httpx.AsyncClient(timeout=15.0, headers=HTTP_HEADERS) as client:
        r = await client.get(SINA_URL)
        r.raise_for_status()
        text = r.text

    m = re.search(r"\{.*\}", text, re.S)
    if not m:
        log.warning("sina: no JSON body")
        return []
    try:
        data = json.loads(m.group(0))
    except json.JSONDecodeError:
        log.warning("sina: json parse failed")
        return []

    items_raw = (data.get("result") or {}).get("data") or []
    out: list[dict] = []
    for it in items_raw:
        title = (it.get("title") or "").strip()
        if not title:
            continue
        url = it.get("url") or ""
        try:
            published = int(it.get("ctime") or it.get("mtime") or 0)
        except (TypeError, ValueError):
            published = 0
        if published == 0:
            continue
        nid = "sina-" + hashlib.md5((url or title).encode("utf-8")).hexdigest()[:16]
        out.append({
            "id": nid,
            "title": title[:200],
            "source": "新浪财经",
            "url": url,
            "published_at": published,
        })
    log.info("sina fetched %d", len(out))
    return out
