import hashlib
import logging
import re

import httpx

from config import HTTP_HEADERS, WALLSTREETCN_URL

log = logging.getLogger("fetcher.wallstreetcn")


def _clean(text: str) -> str:
    text = re.sub(r"<[^>]+>", "", text or "")
    return text.replace("\n", " ").strip()


async def fetch() -> list[dict]:
    async with httpx.AsyncClient(timeout=15.0, headers=HTTP_HEADERS) as client:
        r = await client.get(WALLSTREETCN_URL)
        r.raise_for_status()
        data = r.json()

    items_raw = (data.get("data") or {}).get("items") or []
    out: list[dict] = []
    for it in items_raw:
        title = _clean(it.get("content_text") or it.get("content") or "")
        if not title:
            continue
        title = title[:200]
        url = it.get("uri") or it.get("url") or f"wscn-{it.get('id')}"
        try:
            published = int(it.get("display_time") or it.get("created_at") or 0)
        except (TypeError, ValueError):
            published = 0
        if published == 0:
            continue
        nid = "wscn-" + hashlib.md5(url.encode("utf-8")).hexdigest()[:16]
        out.append({
            "id": nid,
            "title": title,
            "source": "华尔街见闻",
            "url": url,
            "published_at": published,
        })
    log.info("wallstreetcn fetched %d", len(out))
    return out
