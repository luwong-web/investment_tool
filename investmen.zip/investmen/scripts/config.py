import os
from pathlib import Path

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

# 项目根目录:scripts/config.py 的上一层
ROOT_DIR = Path(__file__).parent.parent
DATA_DIR = ROOT_DIR / "data"
DATA_DIR.mkdir(exist_ok=True)

NEWS_JSON = DATA_DIR / "news.json"
STATS_JSON = DATA_DIR / "stats.json"

DEEPSEEK_API_KEY = os.getenv("DEEPSEEK_API_KEY", "").strip()
DEEPSEEK_BASE_URL = "https://api.deepseek.com"
DEEPSEEK_MODEL = "deepseek-chat"

SCORE_BATCH_SIZE = int(os.getenv("SCORE_BATCH_SIZE", "10"))

# 只保留最近 24h 的新闻,避免 JSON 无限增大
RETAIN_HOURS = int(os.getenv("RETAIN_HOURS", "24"))
# 单次运行最多打分数量,控制 token 消耗
MAX_SCORE_PER_RUN = int(os.getenv("MAX_SCORE_PER_RUN", "60"))

WALLSTREETCN_URL = (
    "https://api-one.wallstcn.com/apiv1/content/lives"
    "?channel=global-channel&client=pc&limit=30"
)
SINA_URL = (
    "https://feed.mix.sina.com.cn/api/roll/get"
    "?pageid=155&lid=1686&num=50&versionNumber=1.2.4"
)

HTTP_HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/120.0.0.0 Safari/537.36"
    ),
    "Accept": "application/json, text/plain, */*",
}

USE_MOCK_LLM = not DEEPSEEK_API_KEY
