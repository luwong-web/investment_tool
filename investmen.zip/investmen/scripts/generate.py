"""GitHub Actions 定时入口:抓取新闻 → 与旧 news.json 合并去重 → 批量打分 → 写回 JSON。

运行:python scripts/generate.py
读取:data/news.json(存在则合并)
写出:data/news.json、data/stats.json
"""
import asyncio
import json
import logging
import sys
import time
from pathlib import Path

# 让 scorer.py / fetchers 可以 `from config import ...`
sys.path.insert(0, str(Path(__file__).parent))

from config import (  # noqa: E402
    NEWS_JSON,
    STATS_JSON,
    SCORE_BATCH_SIZE,
    RETAIN_HOURS,
    MAX_SCORE_PER_RUN,
    USE_MOCK_LLM,
)
from fetchers import sina, wallstreetcn  # noqa: E402
from scorer import score_batch  # noqa: E402

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(name)s: %(message)s",
)
log = logging.getLogger("generate")


def load_existing() -> dict[str, dict]:
    if not NEWS_JSON.exists():
        return {}
    try:
        data = json.loads(NEWS_JSON.read_text(encoding="utf-8"))
        return {it["id"]: it for it in data.get("items", []) if it.get("id")}
    except (json.JSONDecodeError, KeyError, OSError) as e:
        log.warning("existing news.json unreadable: %s — starting fresh", e)
        return {}


async def fetch_all() -> list[dict]:
    results = await asyncio.gather(
        wallstreetcn.fetch(),
        sina.fetch(),
        return_exceptions=True,
    )
    merged: list[dict] = []
    for r in results:
        if isinstance(r, Exception):
            log.warning("fetch source failed: %s", r)
            continue
        merged.extend(r)
    return merged


def merge_and_prune(existing: dict[str, dict], fresh: list[dict]) -> dict[str, dict]:
    """把 fresh 合并进 existing;只保留最近 RETAIN_HOURS 小时的记录。"""
    for it in fresh:
        if it["id"] not in existing:
            existing[it["id"]] = {
                **it,
                "impact": None,
                "reason": None,
                "sectors": None,
            }
    cutoff = int(time.time()) - RETAIN_HOURS * 3600
    return {k: v for k, v in existing.items() if v.get("published_at", 0) >= cutoff}


def score_unscored(pool: dict[str, dict]) -> int:
    unscored = [v for v in pool.values() if v.get("impact") is None]
    unscored.sort(key=lambda x: x.get("published_at", 0), reverse=True)
    unscored = unscored[:MAX_SCORE_PER_RUN]

    if not unscored:
        log.info("nothing to score")
        return 0

    log.info("scoring %d items (mock=%s)", len(unscored), USE_MOCK_LLM)
    scored_count = 0
    for i in range(0, len(unscored), SCORE_BATCH_SIZE):
        batch = unscored[i : i + SCORE_BATCH_SIZE]
        try:
            results = score_batch(batch)
        except Exception as e:
            log.exception("score batch failed: %s", e)
            continue
        for s in results:
            item = pool.get(s["id"])
            if item is None:
                continue
            item["impact"] = s.get("impact") or "低"
            item["reason"] = s.get("reason") or ""
            item["sectors"] = s.get("sectors") or []
        scored_count += len(results)
    return scored_count


def compute_stats(items: list[dict]) -> dict:
    now = int(time.time())
    cutoff_24h = now - 24 * 3600
    lt = time.localtime(now)
    today_start = int(time.mktime((lt.tm_year, lt.tm_mon, lt.tm_mday, 0, 0, 0, 0, 0, -1)))

    total = high = mid = low = today_high = 0
    for it in items:
        pub = it.get("published_at", 0)
        if pub < cutoff_24h:
            continue
        total += 1
        imp = it.get("impact")
        if imp == "高":
            high += 1
            if pub >= today_start:
                today_high += 1
        elif imp == "中":
            mid += 1
        elif imp == "低":
            low += 1

    return {
        "total": total,
        "high": high,
        "medium": mid,
        "low": low,
        "today_high": today_high,
        "llm_connected": not USE_MOCK_LLM,
        "generated_at": now,
    }


def write_json(path: Path, obj) -> None:
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(
        json.dumps(obj, ensure_ascii=False, separators=(",", ":")),
        encoding="utf-8",
    )
    tmp.replace(path)


async def main() -> None:
    log.info("=== generate run start ===")
    existing = load_existing()
    log.info("loaded %d existing items", len(existing))

    fresh = await fetch_all()
    log.info("fetched %d fresh items", len(fresh))

    pool = merge_and_prune(existing, fresh)
    log.info("pool size after merge+prune: %d", len(pool))

    scored = score_unscored(pool)
    log.info("scored %d items this run", scored)

    items = sorted(pool.values(), key=lambda x: x.get("published_at", 0), reverse=True)
    write_json(NEWS_JSON, {"items": items, "generated_at": int(time.time())})
    write_json(STATS_JSON, compute_stats(items))
    log.info("wrote %s (%d items) and %s", NEWS_JSON.name, len(items), STATS_JSON.name)


if __name__ == "__main__":
    asyncio.run(main())
